<footer >
    <p class="clearfix pb-3 text-primary text-center">2021 Copyright: BKO | Berke Kaan Öztürk&reg;</p>
</footer>
