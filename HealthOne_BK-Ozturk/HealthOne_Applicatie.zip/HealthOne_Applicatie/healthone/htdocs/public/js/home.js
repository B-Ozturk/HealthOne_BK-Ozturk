//array of news
const news = ["Bij de bar is nu ook lekker koude RedBull verkrijgbaar zodat je vleugels krijgt waardoor je kan vliegen van apparaat naar apparaat.",
"Nieuwe smaak van Redbull Istanblue.",
"Redbull Tropical is weer op voorraad!",
"Redbull The White Edition is nu 1 + 1 !"]

//logo
const logo = "<img src='../img/rb_logo.jpg' width='50px' style='margin:0 8px'/>";
let tickerText = "";
//looping through the news array
for(let i=0; i<news.length; i++){
  tickerText+=news[i];
  //adds the logo in between news items
  if(i!=news.length-1){
    tickerText+=logo;
  }
}

document.querySelector("#scroll").innerHTML = tickerText;